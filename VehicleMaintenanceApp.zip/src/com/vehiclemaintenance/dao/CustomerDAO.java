package com.vehiclemaintenance.dao;

import com.vehiclemaintenance.entity.Customer;

import oracle.jdbc.internal.OracleTypes;

import com.vehiclemaintenance.HibernateUtil;
import org.hibernate.Session;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CustomerDAO {
	

    public Customer getCustomerById(Long customerId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Customer.class, customerId);
        } catch (Exception e) {
            throw new RuntimeException("Failed to fetch customer", e);
        }
    }

    public List<Customer> getAllCustomers() {
        List<Customer> customers = new ArrayList<>();
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            session.beginTransaction();
            Connection connection = session.doReturningWork(conn -> conn);
            CallableStatement stmt = connection.prepareCall("{call Customer_Pkg.Get_All_Customers(?)}");
            stmt.registerOutParameter(1, OracleTypes.CURSOR);
            stmt.execute();
            ResultSet rs = (ResultSet) stmt.getObject(1);
            while (rs.next()) {
                Customer customer = new Customer();
                customer.setCustomerId(rs.getLong("CustomerID"));
                customer.setName(rs.getString("Name"));
                customer.setEmail(rs.getString("Email"));
                customer.setPhone(rs.getString("Phone"));
                customers.add(customer);
            }
            rs.close();
            stmt.close();
            session.getTransaction().commit();
            session.clear(); // Clear the session to avoid any caching
        } catch (Exception e) {
            throw new RuntimeException("Failed to fetch customers", e);
        }
        return customers;
    }

    public void addCustomer(Customer customer) {
        System.out.println("Adding customer: Name=" + customer.getName() + 
                          ", Email=" + customer.getEmail() + 
                          ", Phone=" + customer.getPhone());
        Session session = null;
        Connection connection = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            session.beginTransaction();
            connection = session.doReturningWork(conn -> {
                conn.setAutoCommit(false);
                return conn;
            });
            System.out.println("Connection obtained for addCustomer: " + connection);
            CallableStatement stmt = connection.prepareCall("{call ManageCustomer(?, ?, ?, ?, ?)}");
            stmt.setString(1, "CREATE");
            stmt.setObject(2, null); // CustomerID is auto-generated
            stmt.setString(3, customer.getName());
            stmt.setString(4, customer.getEmail());
            stmt.setString(5, customer.getPhone());
            stmt.execute();
            System.out.println("Stored procedure ManageCustomer executed successfully");
            stmt.close();
            connection.commit();
            session.getTransaction().commit();
            System.out.println("Transaction committed successfully");
        } catch (Exception e) {
            System.err.println("Failed to add customer: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Failed to add customer", e);
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                    System.out.println("JDBC connection closed after adding customer.");
                } catch (SQLException e) {
                    System.err.println("Error closing connection: " + e.getMessage());
                }
            }
            if (session != null && session.isOpen()) {
                session.close();
                System.out.println("Session closed after adding customer.");
            }
        }
    }

    public void updateCustomer(Customer customer) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            session.beginTransaction();
            Connection connection = session.doReturningWork(conn -> conn);
            System.out.println("Updating customer with ID: " + customer.getCustomerId());
            System.out.println("New Name: " + customer.getName() + ", Email: " + customer.getEmail() + ", Phone: " + customer.getPhone());
            
            // Validate input
            if (customer.getName() == null || customer.getName().trim().isEmpty() ||
                customer.getEmail() == null || customer.getEmail().trim().isEmpty() ||
                customer.getPhone() == null || customer.getPhone().trim().isEmpty()) {
                throw new IllegalArgumentException("All customer fields (Name, Email, Phone) must be provided.");
            }

            CallableStatement stmt = connection.prepareCall("{call ManageCustomer(?, ?, ?, ?, ?)}");
            stmt.setString(1, "UPDATE");
            stmt.setLong(2, customer.getCustomerId());
            stmt.setString(3, customer.getName());
            stmt.setString(4, customer.getEmail());
            stmt.setString(5, customer.getPhone());
            stmt.execute();
            stmt.close();
            session.getTransaction().commit();
            System.out.println("Customer updated successfully: " + customer.getCustomerId());
        } catch (SQLException e) {
            if (e.getErrorCode() == 1) { // ORA-00001: unique constraint violated
                throw new RuntimeException("Email " + customer.getEmail() + " is already in use by another customer.", e);
            }
            System.err.println("Error updating customer: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Failed to update customer", e);
        } catch (Exception e) {
            System.err.println("Error updating customer: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Failed to update customer", e);
        }
    }

    public void deleteCustomer(Long customerId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            session.beginTransaction();
            System.out.println("Deleting customer with ID: " + customerId);
            Customer customer = session.get(Customer.class, customerId);
            if (customer != null) {
                session.delete(customer);
            } else {
                System.out.println("Customer with ID " + customerId + " not found.");
            }
            session.getTransaction().commit();
            System.out.println("Customer deleted successfully: " + customerId);
        } catch (Exception e) {
            System.err.println("Error deleting customer: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Failed to delete customer", e);
        }
    }
    
    public void refreshCustomer(Customer customer) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            session.beginTransaction();
            session.refresh(customer); // Refreshes the customer and its associations
            session.getTransaction().commit();
        } catch (Exception e) {
            System.err.println("Error refreshing customer via Hibernate: " + e);
            e.printStackTrace();
            throw new RuntimeException("Failed to refresh customer", e);
        }
    }
}